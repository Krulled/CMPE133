package graph;

import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class GraphImpTest {

   @Test
           (timeout = 100)
   public void sparseTopologicalTest() {
       /*
        * THIS GRAPH IS A DIRECTED ACYCLIC GRAPH
        */

       /*
        * Graph: 1 -> 2, 6, 7
        * 2 -> 3, 6
        * 3 -> 4
        * 4 has no out-degrees
        * 5 -> 4
        * 6 -> 3, 4, 8
        * 7 -> 6, 8
        * 8 -> 5
        */

       ArrayList<Vertex> verts = new ArrayList<Vertex>();

       Vertex v1 = new Vertex(1);
       Vertex v2 = new Vertex(2);
       Vertex v3 = new Vertex(3);
       Vertex v4 = new Vertex(4);
       Vertex v5 = new Vertex(5);
       Vertex v6 = new Vertex(6);
       Vertex v7 = new Vertex(7);
       Vertex v8 = new Vertex(8);
       Vertex v9 = new Vertex(9);
       Vertex v10 = new Vertex(10);

       verts.add(v1);
       verts.add(v2);
       verts.add(v3);
       verts.add(v4);
       verts.add(v5);
       verts.add(v6);
       verts.add(v7);
       verts.add(v8);

       verts.add(v9);
       verts.add(v10);

       ArrayList<Edge> edges = new ArrayList<Edge>();

       // 1 to 2, 6, 7
       edges.add(new Edge(v1, v2));
       edges.add(new Edge(v1, v6));
       edges.add(new Edge(v1, v7));
       // 2 to 3, 6
       edges.add(new Edge(v2, v3));
       edges.add(new Edge(v2, v6));
       // 3 to 4
       edges.add(new Edge(v3, v4));
       // 4 to none

       // 5 to 4
       edges.add(new Edge(v5, v4));
       // 6 to 3, 4, 8
       edges.add(new Edge(v6, v3));
       edges.add(new Edge(v6, v4));
       edges.add(new Edge(v6, v8));
       // 7 to 6, 8
       edges.add(new Edge(v7, v6));
       edges.add(new Edge(v7, v8));
       // 8 to 5
       edges.add(new Edge(v8, v5));

       // DISCONNECTED PORTION
       edges.add(new Edge(v9, v10));

       GraphImp net = new GraphImp(verts, edges);

       String expected = "[9, 10, 1, 7, 2, 6, 8, 5, 3, 4]";

       assertEquals(expected, net.topologicalSortDFS().toString());

       expected = "[1, 9, 2, 7, 10, 6, 3, 8, 5, 4]";

       assertEquals(expected, net.topologicalSortQueue().toString());


       System.out.println("DFS: " + net.depthFirstSearch().toString());
       System.out.println("TOPO dfs: " + net.topologicalSortDFS().toString());
       System.out.println("TOPO queue: " + net.topologicalSortQueue().toString());
   }

   @Test
           (timeout = 100)
   public void topologicalTest2() {
       Vertex zero = new Vertex(0);
       Vertex a = new Vertex(1);
       Vertex b = new Vertex(2);
       Vertex c = new Vertex(3);
       Vertex d = new Vertex(4);
       Vertex e = new Vertex(5);
       Vertex f = new Vertex(6);
       Vertex g = new Vertex(7);
       Vertex h = new Vertex(8);
       Vertex i = new Vertex(9);
       Vertex j = new Vertex(10);
       Vertex k = new Vertex(11);
       Vertex l = new Vertex(12);

       ArrayList<Vertex> verts = new ArrayList<>();
       verts.add(zero);
       verts.add(a);
       verts.add(b);
       verts.add(c);
       verts.add(d);
       verts.add(e);
       verts.add(f);
       verts.add(g);
       verts.add(h);
       verts.add(i);
       verts.add(j);
       verts.add(k);
       verts.add(l);

       ArrayList<Edge> edges = new ArrayList<>();
       edges.add(new Edge(zero, b));
       edges.add(new Edge(zero, c));
       edges.add(new Edge(zero, f));
       edges.add(new Edge(a, d));
       edges.add(new Edge(b, f));
       edges.add(new Edge(c, a));
       edges.add(new Edge(c, d));
       edges.add(new Edge(d, e));
       edges.add(new Edge(d, h));
       edges.add(new Edge(f, g));
       edges.add(new Edge(f, k));
       edges.add(new Edge(g, d));
       edges.add(new Edge(g, l));
       edges.add(new Edge(i, b));
       edges.add(new Edge(i, j));
       edges.add(new Edge(j, f));
       edges.add(new Edge(k, l));
       edges.add(new Edge(l, h));

       GraphImp test = new GraphImp(verts, edges);

       String actual = test.topologicalSortDFS().toString();

       String expected = "[9, 10, 0, 3, 1, 2, 6, 11, 7, 12, 4, 8, 5]";

       assertEquals(expected, actual);

       actual = test.topologicalSortQueue().toString();
       expected = "[0, 9, 3, 2, 10, 1, 6, 7, 11, 4, 12, 5, 8]";

       assertEquals(expected, actual);

   }


}
