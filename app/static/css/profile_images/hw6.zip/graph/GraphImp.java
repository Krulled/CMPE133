package graph;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;
import java.util.Set;
import java.util.HashSet;

public class GraphImp implements Graph{

Map<Vertex, ArrayList<Edge>> graph;



	public GraphImp(Collection<Vertex> vertices, Collection<Edge> edges) {
		graph = new TreeMap<>();
		for (Vertex v : vertices) {
			graph.put(v, new ArrayList<>());
		}

		for (Edge d : edges) {
				Vertex from = d.from;
				Vertex to = d.to;
				int weight = d.weight;
	
				ArrayList<Edge> edgeList = graph.get(from);
				edgeList.add(new Edge(from, to, weight));
	
				edgeList.sort(Comparator.comparing(edge -> edge.to.value));
		}
	}

	public Collection<Vertex> getVertices() {
		ArrayList<Vertex> v = new ArrayList<Vertex>();
		v.addAll(graph.keySet());
		Comparator<Vertex> compareWeights = (Vertex e1, Vertex e2) -> e1.compareTo(e2);
		v.sort(compareWeights);
		return v;
	}

	@Override
	public ArrayList<Integer> depthFirstSearch() {
			for (Vertex d : graph.keySet()) {
				d.color = Color.WHITE;
			}

		Stack<Vertex> stack = new Stack<Vertex>();
		ArrayList<Integer> l = new ArrayList<Integer>();
		int i = 0;

		for (Vertex vert : getVertices()) {
			if (vert.color.equals(Color.WHITE)) {
				vert.color = Color.GREY;
				stack.push(vert);
				i++;
				vert.discoveryTime = i;
				l.add(vert.value);
			}

			while (!stack.isEmpty()) {
				Vertex current = stack.peek();
				Boolean check = false;
				for (Edge edge : graph.get(current)) {
					if (edge.to.color.equals(Color.WHITE)) {
						edge.to.color = Color.GREY;
						edge.to.p = current;
						i++;
						edge.to.discoveryTime = i;
						l.add(edge.to.value);
						
						stack.add(edge.to);
						current = stack.peek();
						check = true;
						break;
					}
				}
					if (check == false) {
						current.color = Color.BLACK;
						i++;
						current.finishTime = i;
						stack.pop();
					}
			}
		}

		return l;
	}

	@Override
	public ArrayList<Integer> topologicalSortDFS() {
	      ArrayList<Integer> DFS = depthFirstSearch();
	      Collection<Vertex> temp = getVertices();
	      ArrayList<Vertex> nL = new ArrayList<>(temp);
	      Collections.sort(nL, new Comparator<Vertex>() {
				@Override
				public int compare(Vertex o1, Vertex o2) {
					return o2.finishTime - o1.finishTime;
				}
			});;
	        
			  ArrayList<Integer> res = new ArrayList<Integer>();
		       for(Vertex v:nL) {
		    	   System.out.println(v.finishTime);
		    	   res.add(v.value);
		       }
		       return res;
	}

	@Override
	public ArrayList<Integer> topologicalSortQueue() {
				ArrayList<Integer> l = new ArrayList<Integer>();
		
				ArrayList<Vertex> vertices = (ArrayList<Vertex>) getVertices();
				int[] inDegrees = new int[vertices.size()];
		
				for (Vertex e : vertices) {
					e.color = Color.WHITE;
				}

		Queue<Vertex> queue = new LinkedList<Vertex>();

		for (Map.Entry<Vertex, ArrayList<Edge>> eL : graph.entrySet()) {
			for (Edge e : eL.getValue()) {
				inDegrees[vertices.indexOf(e.to)] ++;
			}
		}

				for (int i = 0; i < vertices.size(); i++) {
					if (vertices.get(i).color == Color.WHITE && inDegrees[i] == 0) {
						vertices.get(i).color = Color.GREY;
						queue.offer(vertices.get(i));
					}
				}

			while (!queue.isEmpty()) {
				Vertex target = queue.poll();
				if (target.color == Color.GREY) {
					l.add(target.value);
					target.color = Color.BLACK;
					for (Edge x : graph.get(target)) {
						inDegrees[vertices.indexOf(x.to)] -= 1;
					}
				}
	
				for (int i = 0; i < vertices.size(); i++) {
					if (vertices.get(i).color == Color.WHITE && inDegrees[i] == 0) {
						vertices.get(i).color = Color.GREY;
						queue.offer(vertices.get(i));
					}
				}
			}
			return l;
		}


	@Override
	public ArrayList<Integer> shortestPath(int source, int target) {

	   ArrayList<Integer> sP = new ArrayList<>();

	   ArrayList<Vertex> vertices = (ArrayList<Vertex>) getVertices();

	   int sI = -1;
	   int tI = -1;
	   int n = vertices.size();
	   for (int i = 0; i < n; i++) {
	       if (vertices.get(i).value == source)
	           sI = i;
	       if (vertices.get(i).value == target)
	           tI = i;
	   }


	   for (int i = 0; i < n; i++) {
	       vertices.get(i).discoveryTime = Integer.MAX_VALUE;
	   }
	   vertices.get(sI).discoveryTime = 0;

	   Set<Vertex> visited = new HashSet<>();

	   for (int k = 0; k < n; k++) {

	       Vertex nearestVertex = null;
	       int min = Integer.MAX_VALUE;
	       for (int i = 0; i < n; i++) {
	           Vertex v = vertices.get(i);
	           if (!visited.contains(v) && v.discoveryTime < min) {
	               min = v.discoveryTime;
	               nearestVertex = v;
	           }
	       }
	       
	       if (nearestVertex == null)
	           break;

	       		visited.add(nearestVertex);

	       for (Edge e : graph.get(nearestVertex)) {
	           if (e.to.discoveryTime > nearestVertex.discoveryTime + e.weight) {
	               e.to.discoveryTime = nearestVertex.discoveryTime + e.weight;
	               e.to.p = nearestVertex;
	           }
	       }
	   }

			   Vertex v = vertices.get(tI);
				   while (v.p != null) {
				       sP.add(v.value);
				       v = v.p;
				   }
				   sP.add(source);

	   Collections.reverse(sP);
	   return sP;
	}
	
	public static void main(String[] args)
    {

		
		        Vertex a=new Vertex(0);
		        Vertex b=new Vertex(1);
		        Vertex c=new Vertex(2);
		        Vertex d=new Vertex(3);
		        Vertex e=new Vertex(4);
		        Vertex f=new Vertex(5);
		
 		        Edge ab=new Edge(a,b,2);
 		        Edge ac=new Edge(a,c,5);
 		        Edge bd=new Edge(b,d,1);
 		        Edge de=new Edge(d,e,3);
 		        Edge df=new Edge(d,f,3);
 		        Edge af=new Edge(a,f,10);
		 
 		        ArrayList<Vertex>v=new ArrayList<Vertex>(Arrays.asList(a,b,c,d,e,f));
 		        ArrayList<Edge>edges=new ArrayList<Edge>(Arrays.asList(ab,ac,bd,de,df,af));
		 
 		        GraphImp G=new GraphImp(v,edges);
		 
		 
 		         //print vertices and Edges of Graph
 		         //perform DFS on Graph
 		        ArrayList<Integer> ans= G.depthFirstSearch();
 		        System.out.println("After performing DFS we get:");
		
			for(Integer i:ans)
		            System.out.print(i+" ");
		
		         //perform Topological Sort on Graph using DFS
		        ans= G.topologicalSortDFS();
		        System.out.println("\nAfter Topological Sort on Graph using DFS we get:");
		
		        for(Integer i:ans)
		            System.out.print(i+" ");
		
		
		         //perform Topological Sort on Graph using Queue
		        ans= G.topologicalSortQueue();
		        System.out.println("\nAfter Topological Sort on Graph using Queue we get:");
		
		        for(Integer i:ans)
		            System.out.print(i+" ");
		
		        // Find Shortest path between Vertex a and Vertex f
		        ans= G.shortestPath(0,5);
		        System.out.println("\nShortest path between 0 and 5 using Dijkstra Algorithm:");
		
		        for(Integer i:ans)
		            System.out.print(i+" ");
    }


}

	
	
