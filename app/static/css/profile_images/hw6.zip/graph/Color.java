package graph;

public enum Color { //for coloring nodes 
	BLACK, WHITE, GREY;
}
