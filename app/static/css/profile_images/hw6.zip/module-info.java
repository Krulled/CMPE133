module hw6test {
	requires org.junit.jupiter.api;
	requires junit;
}